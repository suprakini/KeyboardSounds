import pynput.keyboard
import numpy as np
import sounddevice as sd
import random
import os
import miniaudio

# Audio Constants
FS = 44100
DURATION = 0.2
VOLUME = 0.8
# LOWER THIS NUMBER IF STILL TOO LOUD (e.g., 0.02 or 0.01)
MP3_GAIN = 0.05 

# Global State
current_wave = np.zeros(int(FS * DURATION), dtype=np.float32)
play_pos = 0
is_playing = False
pressed_keys = set()
KEY_MAP = {}
SELECTED_PROFILE = 1
STOP_LISTENER = False

def load_custom_mp3():

    try:
        directory = os.path.dirname(os.path.abspath(__file__))
        target = "input.mp3"
        filename = next((f for f in os.listdir(directory) if f.lower() == target), None)
        
        if not filename:
            return np.zeros(int(FS * DURATION), dtype=np.float32)

        path = os.path.join(directory, filename)
        decoded = miniaudio.decode_file(path, sample_rate=FS, nchannels=1)
        samples = np.array(decoded.samples, dtype=np.float32)
        
        return samples * MP3_GAIN
        
    except Exception:
        return np.zeros(int(FS * DURATION), dtype=np.float32)

def stretch_audio(data, rate):

    if rate == 1.0:
        return data
    old_indices = np.arange(len(data))
    new_indices = np.arange(0, len(data), rate)
    return np.interp(new_indices, old_indices, data).astype(np.float32)

def audio_callback(outdata, frames, time, status):
    global play_pos, is_playing, current_wave
    if is_playing:
        remaining = len(current_wave) - play_pos
        if remaining <= 0:
            is_playing = False
            outdata.fill(0)
            return
        num_frames = min(frames, remaining)
        outdata[:num_frames, 0] = current_wave[play_pos:play_pos + num_frames]
        outdata[num_frames:, 0] = 0
        play_pos += num_frames
    else:
        outdata.fill(0)

def generate_sound(freq, profile):
    t = np.linspace(0, DURATION, int(FS * DURATION), False)
    
    if profile == 22:
        base_mp3 = load_custom_mp3()
        speed_rate = random.uniform(0.8, 1.2)
        return stretch_audio(base_mp3, speed_rate)
        
    if profile == 1: 
        env = np.exp(-35 * t / DURATION); wave = np.sin(2 * np.pi * freq * t) * env
    elif profile == 2: 
        env = np.exp(-45 * t / DURATION); wave = (np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(3 * np.pi * freq * t)) * env
    elif profile == 3: 
        env = np.exp(-60 * (t**1.2) / DURATION); wave = np.sin(2 * np.pi * freq * t) * env
    elif profile == 4: 
        env = np.exp(-25 * t / DURATION); wave = np.sin(2 * np.pi * (freq * 0.4) * t) * env
    elif profile == 5: 
        env = np.ones_like(t); env[int(len(t)*0.4):] = 0; wave = np.sin(2 * np.pi * 800 * t) * env
    elif profile == 6: 
        env = np.exp(-90 * t / DURATION); noise = (np.random.rand(len(t)) - 0.5) * 0.4; wave = noise * env
    elif profile == 7: 
        env = np.ones_like(t); env[int(len(t)*0.5):] = 0; wave = (np.sin(2 * np.pi * 350 * t) + np.sin(2 * np.pi * 440 * t)) * env
    elif profile == 8: 
        env = np.ones_like(t); env[int(len(t)*0.8):] = 0; wave = np.sin(2 * np.pi * 1000 * t) * env
    elif profile == 9: 
        env = np.exp(-100 * t / DURATION); wave = (np.sin(2 * np.pi * 1200 * t) + np.random.normal(0, 0.1, len(t))) * env
    elif profile == 10: 
        env = np.exp(-50 * t / DURATION); wave = np.random.uniform(-1, 1, len(t)) * env
    elif profile == 11: 
        wave = np.sin(2 * np.pi * freq * t) * (t < 0.02)
    elif profile == 12: 
        env = np.exp(-15 * t / DURATION); wave = np.sin(2 * np.pi * freq * 1.5 * t) * env
    elif profile == 13: 
        wave = np.sin(2 * np.pi * freq * (1 - t/DURATION) * t) * np.exp(-5 * t/DURATION)
    elif profile == 14: 
        wave = np.tan(np.sin(2 * np.pi * freq * t)) * 0.2 * np.exp(-40 * t/DURATION)
    elif profile == 15: 
        wave = np.sin(2 * np.pi * freq * t) * np.sin(2 * np.pi * 50 * t) * np.exp(-20 * t/DURATION)
    elif profile == 16: 
        env = np.exp(-30 * t / DURATION); wave = (np.sin(2 * np.pi * 150 * t) + np.random.normal(0, 0.2, len(t))) * env
    elif profile == 17: 
        env = np.exp(-20 * t / DURATION); wave = np.sin(2 * np.pi * 2500 * t) * env
    elif profile == 18: 
        env = np.exp(-40 * t / DURATION); wave = (np.sin(2 * np.pi * 3000 * t) + np.sin(2 * np.pi * 3200 * t)) * env
    elif profile == 19: 
        env = np.exp(-50 * t / DURATION); wave = np.sin(2 * np.pi * 100 * t) * env
    elif profile == 20: 
        wave = np.sign(np.sin(2 * np.pi * 100 * t)) * 0.2 * (t < 0.1)
    elif profile == 21: 
        envelope = np.exp(-15 * t / DURATION) * (np.sin(np.pi * t / DURATION))
        noise = (np.random.rand(len(t)) - 0.5) * 0.5
        wave = noise * envelope
    else: wave = np.zeros_like(t)
    return (wave * VOLUME).astype(np.float32)

def on_press(key):
    global current_wave, play_pos, is_playing
    if key not in pressed_keys:
        pressed_keys.add(key)
        try:
            k = str(key)
            if k not in KEY_MAP:
                pitch = random.randint(400, 1000)
                KEY_MAP[k] = generate_sound(pitch, SELECTED_PROFILE)
            current_wave = KEY_MAP[k]; play_pos = 0; is_playing = True
        except: pass

def on_release(key):
    if key in pressed_keys: pressed_keys.remove(key)

def run_sounds():
    global SELECTED_PROFILE, KEY_MAP, STOP_LISTENER
    sounds = ["Bubble Pop", "Wood Block", "Raindrop", "Soft Thump", "PC Beep", "Typewriter", "Phone Tone", "Microwave", "Switch", "Camera", "Blip", "Ping", "Laser", "Zap", "Robot", "Hammer", "Glass", "Coin", "Knock", "Buzz", "Kiss", "Custom MP3"]
    
    while True:
        print("\n--- SELECT SOUND ---")
        for i, name in enumerate(sounds, 1):
            print(f"{i}: {name}")
        
        choice = input("\nEnter Sound Number (or 'exit' to quit): ")
        if choice.lower() == 'exit':
            STOP_LISTENER = True
            break
            
        try:
            SELECTED_PROFILE = int(choice)
            KEY_MAP = {}
            print(f"\n[{sounds[SELECTED_PROFILE-1]}] Active! Type 999 here to change sound.")
            
            sub_choice = input()
            if sub_choice == "999":
                continue
            elif sub_choice.lower() == "exit":
                STOP_LISTENER = True
                break
        except:
            print("Invalid selection.")

if __name__ == "__main__":
    print(sd.query_devices())
    device_id = input("\nEnter Device ID: ")
    sd.default.device = (None, int(device_id))
    
    with sd.OutputStream(channels=1, callback=audio_callback, samplerate=FS, blocksize=128):
        listener = pynput.keyboard.Listener(on_press=on_press, on_release=on_release)
        listener.start()
        run_sounds()
        listener.stop()
